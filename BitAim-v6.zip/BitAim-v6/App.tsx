/**
 * BitAim v6 — Carrom Pool Aim Assistant
 * Changes from v5:
 *  - Proper Autoplay toggle (uses setAutoSwipeEnabled + setSnapMode together)
 *  - Accessibility Service permission check & prompt for Autoplay
 *  - Removed "Prediction Lines" / Shot Mode card (no aim-line mode selector)
 *  - Removed "Auto-Detect (Live CV)" toggle — board detection is manual only
 *  - Manual Board section is now the primary board setup (promoted to top)
 *  - Board edge fine-tune sliders replace auto-detect sensitivity
 */

import React, {useState, useEffect, useCallback} from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Alert,
  Switch, ScrollView, Platform, StatusBar,
  NativeModules, Linking, PermissionsAndroid,
} from 'react-native';
import Slider from '@react-native-community/slider';

const {OverlayModule} = NativeModules;

export default function App() {
  const [hasOverlay,       setHasOverlay]       = useState(false);
  const [overlayActive,    setOverlayActive]     = useState(false);
  const [autoplayOn,       setAutoplayOn]        = useState(false);
  const [accessibilityOk,  setAccessibilityOk]   = useState(false);
  const [strikerMoveable,  setStrikerMoveable]   = useState(true);
  const [manualBoardMode,  setManualBoardMode]   = useState(false);
  const [sensitivity,      setSensitivity]       = useState(1.0);
  const [offsetX,          setOffsetX]           = useState(0);
  const [offsetY,          setOffsetY]           = useState(0);

  // Board edge fine-tune insets
  const [insetTop,    setInsetTop]    = useState(0);
  const [insetBottom, setInsetBottom] = useState(0);
  const [insetLeft,   setInsetLeft]   = useState(0);
  const [insetRight,  setInsetRight]  = useState(0);

  useEffect(() => {
    if (Platform.OS === 'android' && Platform.Version >= 33) {
      PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS).catch(() => {});
    }
    refreshStatus();
    const t = setInterval(refreshStatus, 2000);
    return () => clearInterval(t);
  }, []);

  const refreshStatus = useCallback(async () => {
    try { setHasOverlay(await OverlayModule.canDrawOverlays()); } catch { setHasOverlay(true); }
    try { setAccessibilityOk(await OverlayModule.isAccessibilityEnabled()); } catch {}
  }, []);

  const requestOverlay = useCallback(() => {
    try {
      OverlayModule.requestOverlayPermission();
      setTimeout(refreshStatus, 1500);
    } catch {
      Alert.alert('Permission Needed', 'Grant "Display over other apps" in Settings.',
        [{text: 'Open Settings', onPress: () => Linking.openSettings()}]);
    }
  }, [refreshStatus]);

  const toggleOverlay = useCallback(async () => {
    if (!hasOverlay) { requestOverlay(); return; }
    try {
      if (overlayActive) {
        await OverlayModule.stopOverlay();
        setOverlayActive(false);
        setAutoplayOn(false);
        setManualBoardMode(false);
      } else {
        await OverlayModule.startOverlay();
        setOverlayActive(true);
        try { OverlayModule.setStrikerMoveable(strikerMoveable); } catch {}
        try { OverlayModule.setSnapMode(false); } catch {}
        try { OverlayModule.setAutoSwipeEnabled(false); } catch {}
      }
    } catch (e: any) { Alert.alert('Error', e.message); }
  }, [hasOverlay, overlayActive, strikerMoveable, requestOverlay]);

  /** Autoplay = snap-aim ON + auto-swipe ON. Requires Accessibility Service. */
  const toggleAutoplay = useCallback(() => {
    if (!overlayActive) {
      Alert.alert('Start Overlay First', 'Turn on the Aim Overlay before enabling Autoplay.');
      return;
    }
    if (!autoplayOn && !accessibilityOk) {
      Alert.alert(
        'Accessibility Permission Required',
        'Autoplay needs the Bit-Aim Accessibility Service to perform swipe shots.\n\nSettings → Accessibility → Installed Services → Bit-Aim → Enable.',
        [
          {text: 'Open Settings', onPress: () => { try { OverlayModule.openAccessibilitySettings(); } catch {} }},
          {text: 'Cancel', style: 'cancel'},
        ],
      );
      return;
    }
    const next = !autoplayOn;
    setAutoplayOn(next);
    try { OverlayModule.setSnapMode(next); }        catch {}
    try { OverlayModule.setAutoSwipeEnabled(next); } catch {}
  }, [overlayActive, autoplayOn, accessibilityOk]);

  const toggleStrikerMoveable = useCallback((val: boolean) => {
    setStrikerMoveable(val);
    try { OverlayModule.setStrikerMoveable(val); } catch {}
  }, []);

  const toggleManualBoard = useCallback((val: boolean) => {
    if (!overlayActive) {
      Alert.alert('Start Overlay First', 'Turn on the overlay, then draw the board.');
      return;
    }
    setManualBoardMode(val);
    try { OverlayModule.setManualBoardMode(val); } catch {}
  }, [overlayActive]);

  const clearBoard = useCallback(() => {
    try { OverlayModule.clearManualBoard(); } catch {}
    setManualBoardMode(false);
  }, []);

  const pushInsets = (t: number, b: number, l: number, r: number) => {
    try { (OverlayModule as any).setManualBoardInsets(t, b, l, r); } catch {}
  };

  const handleInset = useCallback((side: 'top'|'bottom'|'left'|'right', val: number) => {
    let t=insetTop, b=insetBottom, l=insetLeft, r=insetRight;
    if (side==='top')    { t=val; setInsetTop(val); }
    if (side==='bottom') { b=val; setInsetBottom(val); }
    if (side==='left')   { l=val; setInsetLeft(val); }
    if (side==='right')  { r=val; setInsetRight(val); }
    pushInsets(t, b, l, r);
  }, [insetTop, insetBottom, insetLeft, insetRight]);

  const handleSensitivity = useCallback((val: number) => {
    setSensitivity(val);
    try { OverlayModule.setSensitivity(val); } catch {}
  }, []);

  const handleOffset = useCallback((axis: 'X'|'Y', val: number) => {
    const nx = axis==='X' ? val : offsetX;
    const ny = axis==='Y' ? val : offsetY;
    if (axis==='X') setOffsetX(val); else setOffsetY(val);
    try { OverlayModule.setMarginOffset(nx, ny); } catch {}
  }, [offsetX, offsetY]);

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor="#0D0D1A" />
      <View style={s.header}>
        <Text style={s.logo}>Bit-Aim  v6</Text>
        <Text style={s.sub}>Carrom Aim Assist — Manual Board • Autoplay</Text>
      </View>

      <ScrollView style={s.scroll} contentContainerStyle={s.scrollContent}
        showsVerticalScrollIndicator={false}>

        {!hasOverlay && (
          <TouchableOpacity style={s.permBanner} onPress={requestOverlay}>
            <Text style={s.permText}>Tap to grant "Display over other apps" →</Text>
          </TouchableOpacity>
        )}

        {/* ── Core toggles ── */}
        <View style={s.card}>
          <Row title="Aim Overlay" color="#FFD700"
            sub={overlayActive ? 'Running — tap floating icon in-game' : 'Start aim lines over Carrom Pool'}
            value={overlayActive} onToggle={toggleOverlay} />

          <Sep />

          <Row
            title="Autoplay  🎯"
            color="#22FF6E"
            sub={
              !accessibilityOk
                ? '⚠ Enable Bit-Aim Accessibility Service first'
                : autoplayOn
                  ? '✓ Auto-aims & shoots at best coin each frame'
                  : 'Auto-lock aim + perform swipe shot automatically'
            }
            value={autoplayOn}
            onToggle={toggleAutoplay}
          />

          {!accessibilityOk && (
            <TouchableOpacity style={s.accessBanner}
              onPress={() => { try { OverlayModule.openAccessibilitySettings(); } catch {} }}>
              <Text style={s.accessText}>
                Autoplay needs Accessibility Service → Tap to open Settings
              </Text>
            </TouchableOpacity>
          )}

          <Sep />

          <Row title="Moveable Striker" color="#FF8A00"
            sub={strikerMoveable ? 'Drag gold-ringed striker to reposition' : 'Striker locked to position'}
            value={strikerMoveable} onToggle={toggleStrikerMoveable} />
        </View>

        {/* ── Board Setup ── PRIMARY ── */}
        <View style={[s.card, manualBoardMode && s.activeCard]}>
          <Text style={s.cardTitle}>Board Setup</Text>
          <Text style={s.cardSub}>
            Draw the board boundary on the overlay. Fine-tune each edge with the sliders.
            No auto-detection needed.
          </Text>

          <View style={s.btnRow}>
            <TouchableOpacity
              style={[s.btn, manualBoardMode && s.btnActive]}
              onPress={() => toggleManualBoard(!manualBoardMode)}>
              <Text style={[s.btnTxt, manualBoardMode && s.btnTxtActive]}>
                {manualBoardMode ? '✓ Drawing Mode ON' : 'Draw Board'}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={s.btnDanger} onPress={clearBoard}>
              <Text style={s.btnDangerTxt}>Clear Board</Text>
            </TouchableOpacity>
          </View>

          {manualBoardMode && (
            <View style={s.infoBox}>
              <Text style={s.infoTxt}>
                {'→ Switch to the game\n→ Drag finger to draw board outline\n→ Use 2 fingers for precise corners\n→ Drag corner handles to adjust\n→ Come back and tap "Drawing Mode ON" to confirm'}
              </Text>
            </View>
          )}

          {/* Edge fine-tune sliders */}
          <Text style={[s.sectionLabel, {marginTop: 18}]}>Fine-Tune Board Edges</Text>
          <Text style={s.cardSub}>Nudge each edge inward (+) or outward (−).</Text>

          {(
            [
              {label: 'Top',    side: 'top',    val: insetTop},
              {label: 'Bottom', side: 'bottom', val: insetBottom},
              {label: 'Left',   side: 'left',   val: insetLeft},
              {label: 'Right',  side: 'right',  val: insetRight},
            ] as const
          ).map(({label, side, val}) => (
            <View key={side}>
              <View style={s.rowSp}>
                <Text style={s.marginLbl}>{label}</Text>
                <Text style={s.marginVal}>{val > 0 ? `+${val}` : val}</Text>
              </View>
              <Slider style={s.slider}
                minimumValue={-80} maximumValue={80} step={1}
                value={val}
                onValueChange={v => handleInset(side, v)}
                minimumTrackTintColor="#00E5FF"
                maximumTrackTintColor="#333"
                thumbTintColor="#00E5FF" />
            </View>
          ))}

          <TouchableOpacity style={s.resetBtn}
            onPress={() => {
              setInsetTop(0); setInsetBottom(0); setInsetLeft(0); setInsetRight(0);
              pushInsets(0, 0, 0, 0);
            }}>
            <Text style={s.resetTxt}>Reset Edges</Text>
          </TouchableOpacity>
        </View>

        {/* ── Shot Power ── */}
        <View style={s.card}>
          <View style={s.rowSp}>
            <Text style={s.cardTitle}>Shot Power</Text>
            <Text style={s.val}>{sensitivity.toFixed(1)}×</Text>
          </View>
          <Slider style={s.slider} minimumValue={0.3} maximumValue={3.0} step={0.1}
            value={sensitivity} onValueChange={handleSensitivity}
            minimumTrackTintColor="#FFD700" maximumTrackTintColor="#333" thumbTintColor="#FFD700" />
          <View style={s.rowSp}><Text style={s.end}>Soft</Text><Text style={s.end}>Hard</Text></View>
        </View>

        {/* ── Fine Tune Aim Offset ── */}
        <View style={s.card}>
          <Text style={s.cardTitle}>Fine-Tune Aim Offset</Text>
          <Text style={s.cardSub}>Nudge aim lines if there's a small screen offset.</Text>
          <View style={s.rowSp}>
            <Text style={s.marginLbl}>X</Text>
            <Text style={s.marginVal}>{offsetX.toFixed(1)}</Text>
          </View>
          <Slider style={s.slider} minimumValue={-30} maximumValue={30} step={0.5}
            value={offsetX} onValueChange={v => handleOffset('X', v)}
            minimumTrackTintColor="#00E5FF" maximumTrackTintColor="#333" thumbTintColor="#00E5FF" />
          <View style={s.rowSp}>
            <Text style={s.marginLbl}>Y</Text>
            <Text style={s.marginVal}>{offsetY.toFixed(1)}</Text>
          </View>
          <Slider style={s.slider} minimumValue={-30} maximumValue={30} step={0.5}
            value={offsetY} onValueChange={v => handleOffset('Y', v)}
            minimumTrackTintColor="#00E5FF" maximumTrackTintColor="#333" thumbTintColor="#00E5FF" />
          <TouchableOpacity style={s.resetBtn}
            onPress={() => {
              setOffsetX(0); setOffsetY(0);
              try { OverlayModule.setMarginOffset(0, 0); } catch {}
            }}>
            <Text style={s.resetTxt}>Reset Offset</Text>
          </TouchableOpacity>
        </View>

        {/* ── How to Use ── */}
        <View style={s.card}>
          <Text style={s.cardTitle}>How to Use</Text>
          <Step n="1" t='Grant "Draw over other apps" permission' />
          <Step n="2" t="Turn on Aim Overlay" />
          <Step n="3" t='Tap "Draw Board" → switch to game → drag to outline the board' hi />
          <Step n="4" t="Use edge sliders to fine-tune each side of the board" hi />
          <Step n="5" t="Open Carrom Pool, tap floating icon to show aim lines" />
          <Step n="6" t="Tap board to set aim target" />
          <Step n="7" t="Enable Autoplay for auto-aim + auto-swipe each turn" hi />
          <Step n="8" t="Grant Accessibility Service when prompted for Autoplay" hi />
          <Step n="9" t="Drag the gold-ringed striker to reposition it" />
        </View>

        <View style={s.footer}>
          <Text style={s.footerTxt}>Bit-Aim v6 — Manual Board • Autoplay</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function Row({title,sub,value,onToggle,color}: {
  title: string; sub: string; value: boolean;
  onToggle: (v: boolean) => void; color: string;
}) {
  return (
    <View style={s.row}>
      <View style={{flex:1,paddingRight:10}}>
        <Text style={s.cardTitle}>{title}</Text>
        <Text style={s.cardSub}>{sub}</Text>
      </View>
      <Switch value={value} onValueChange={onToggle}
        trackColor={{false:'#333',true:color}} thumbColor={value?'#FFF':'#888'} />
    </View>
  );
}
function Sep() { return <View style={{height:1,backgroundColor:'#222244',marginVertical:12}}/>; }
function Step({n,t,hi}: {n:string;t:string;hi?:boolean}) {
  return (
    <View style={s.stepRow}>
      <View style={[s.badge,hi&&s.badgeHi]}><Text style={[s.badgeN,hi&&{color:'#22FF6E'}]}>{n}</Text></View>
      <Text style={[s.stepTxt,hi&&{color:'#22FF6E',fontWeight:'700'}]}>{t}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  root:{flex:1,backgroundColor:'#0D0D1A'},
  header:{
    paddingTop:Platform.OS==='android'?StatusBar.currentHeight??24:44,
    paddingBottom:16,paddingHorizontal:20,
    backgroundColor:'#13132A',borderBottomWidth:1,borderBottomColor:'#222244',
  },
  logo:{color:'#FFD700',fontSize:26,fontWeight:'900',letterSpacing:1},
  sub:{color:'#8888BB',fontSize:11,marginTop:2},
  scroll:{flex:1},
  scrollContent:{padding:16,paddingBottom:40},
  permBanner:{
    backgroundColor:'#2A1A00',borderWidth:1,borderColor:'#FFD700',
    borderRadius:10,padding:14,marginBottom:12,
  },
  permText:{color:'#FFD700',fontSize:13,fontWeight:'700'},
  accessBanner:{
    backgroundColor:'#1A1800',borderWidth:1,borderColor:'#FFD70066',
    borderRadius:8,padding:10,marginTop:10,
  },
  accessText:{color:'#FFD700',fontSize:12},
  card:{
    backgroundColor:'#16162E',borderRadius:14,padding:16,
    marginBottom:14,borderWidth:1,borderColor:'#222244',
  },
  activeCard:{borderColor:'#00E5FF',backgroundColor:'#0A1A2A'},
  cardTitle:{color:'#FFF',fontSize:15,fontWeight:'700',marginBottom:3},
  cardSub:{color:'#8888BB',fontSize:12,marginBottom:4},
  sectionLabel:{color:'#CCCCEE',fontSize:13,fontWeight:'700',marginBottom:4},
  row:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},
  rowSp:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  btnRow:{flexDirection:'row',gap:10,marginTop:12},
  btn:{
    flex:1,paddingVertical:10,borderRadius:9,
    backgroundColor:'#1E1E3A',alignItems:'center',
    borderWidth:1.5,borderColor:'#333355',
  },
  btnActive:{borderColor:'#00E5FF',backgroundColor:'#00151F'},
  btnTxt:{color:'#8888BB',fontSize:13,fontWeight:'600'},
  btnTxtActive:{color:'#00E5FF'},
  btnDanger:{
    paddingVertical:10,paddingHorizontal:16,borderRadius:9,
    backgroundColor:'#2A0000',borderWidth:1.5,borderColor:'#FF4444',
  },
  btnDangerTxt:{color:'#FF7777',fontSize:13,fontWeight:'600'},
  infoBox:{
    backgroundColor:'#071830',borderRadius:8,padding:12,marginTop:10,
    borderWidth:1,borderColor:'#00E5FF44',
  },
  infoTxt:{color:'#7BBBFF',fontSize:12,lineHeight:20},
  slider:{width:'100%',height:36},
  val:{color:'#FFD700',fontSize:16,fontWeight:'700'},
  end:{color:'#666688',fontSize:11},
  marginLbl:{color:'#AAA',fontSize:13,marginBottom:2},
  marginVal:{color:'#00E5FF',fontWeight:'700'},
  resetBtn:{
    marginTop:8,paddingVertical:8,borderRadius:8,
    backgroundColor:'#1E1E3A',alignItems:'center',
    borderWidth:1,borderColor:'#444466',
  },
  resetTxt:{color:'#FF7777',fontSize:13,fontWeight:'600'},
  stepRow:{flexDirection:'row',alignItems:'flex-start',marginBottom:8},
  badge:{
    width:22,height:22,borderRadius:11,backgroundColor:'#1E1E3A',
    alignItems:'center',justifyContent:'center',
    marginRight:10,marginTop:1,borderWidth:1,borderColor:'#333355',
  },
  badgeHi:{borderColor:'#22FF6E'},
  badgeN:{color:'#8888BB',fontSize:11,fontWeight:'700'},
  stepTxt:{color:'#CCCCEE',fontSize:13,flex:1},
  footer:{alignItems:'center',marginTop:10},
  footerTxt:{color:'#444466',fontSize:11},
});
